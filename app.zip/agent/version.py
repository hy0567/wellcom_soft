"""WellcomAgent 버전 정보 (단일 소스)"""

__version__ = "3.2.0"
__app_name__ = "WellcomAgent"
__github_repo__ = "hy0567/wellcom_soft"
__asset_name__ = "agent.zip"
